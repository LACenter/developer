////////////////////////////////////////////////////////////////////////////////
// Unit Description  : [UNIT] Description
// Unit Author       : [AUTHOR]
// Date Created      : [DATE]
// -----------------------------------------------------------------------------
//
// History
//
//
////////////////////////////////////////////////////////////////////////////////


import "mainform";

//<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

function AppException(Sender, E) {
    //Uncaught Exceptions
    MsgError("Error", E.Message);
}

//[UNIT] initialization constructor
Application.Initialize;
Application.Icon.LoadFromResource("appicon");
Application.Title = "[UNIT]";
mainformCreate(null);
Application.Run;

//Project Resources
//$res:appicon=[project-home]resources/app.ico
//$res:mainform=[project-home]mainform.js.frm
