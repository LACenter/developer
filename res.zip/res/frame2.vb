'///////////////////////////////////////////////////////////////////////////////
' Unit Description  : [UNIT] Description
' Unit Author       : [AUTHOR]
' Date Created      : [DATE]
' ------------------------------------------------------------------------------
'
' History
'
'
'///////////////////////////////////////////////////////////////////////////////

'constructor of [UNIT]
function [UNIT]Create(Owner as TComponent) as TFrame
    return TFrame.CreateWithConstructor(Owner, addressof [UNIT]_OnCreate)
end function

'OnCreate Event of [UNIT]
sub [UNIT]_OnCreate(Sender as TFrame)
    'Frame Constructor

    'todo: some additional constructing code
end sub

'<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

'[UNIT] initialization constructor


