////////////////////////////////////////////////////////////////////////////////
// Unit Description  : [UNIT] Description
// Unit Author       : [AUTHOR]
// Date Created      : [DATE]
// -----------------------------------------------------------------------------
//
// History
//
//
////////////////////////////////////////////////////////////////////////////////

//constructor of [UNIT]
function [UNIT]Create(Owner) {
    return TForm.CreateWithConstructor(Owner, &[UNIT]_OnCreate);
}

//OnCreate Event of [UNIT]
function [UNIT]_OnCreate(Sender) {
    //Form Constructor

    //todo: some additional constructing code
}

//<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

//[UNIT] initialization constructor
