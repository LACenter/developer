func
=function NAME() as TYPE
=
=end function
----------------------------------
proc
=sub NAME()
=
=end sub
----------------------------------
if
=if (CONDITION) then
=
=end if
----------------------------------
ifelse
=if (CONDITION) then
=
=else
=
=end if
----------------------------------
for
=for i = 0 to AMOUNT
=
=next
----------------------------------
while
=while CONDITION
=
=wend
----------------------------------
sf
=Sender.Find("")
----------------------------------
so
=Sender.Owner.Find("")
