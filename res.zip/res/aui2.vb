'///////////////////////////////////////////////////////////////////////////////
' Unit Description  : [UNIT] Description
' Unit Author       : [AUTHOR]
' Date Created      : [DATE]
' ------------------------------------------------------------------------------
'
' History
'
'
'///////////////////////////////////////////////////////////////////////////////


imports "mainform"

'<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

'[UNIT] initialization constructor
Application.Initialize
Application.Title = "[UNIT]"
mainformCreate(null)
Application.Run
