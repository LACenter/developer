////////////////////////////////////////////////////////////////////////////////
// Unit Description  : [UNIT] Description
// Unit Author       : [AUTHOR]
// Date Created      : [DATE]
// -----------------------------------------------------------------------------
//
// History
//
//
////////////////////////////////////////////////////////////////////////////////

//constructor of [UNIT]
function [UNIT]Create(Owner) {
    return TFrame.CreateWithConstructorFromResource(Owner, &[UNIT]_OnCreate, "[UNIT]");
}

//OnCreate Event of [UNIT]
function [UNIT]_OnCreate(Sender) {
    //Frame Constructor

    //todo: some additional constructing code

    //note: DESIGNER TAG => DO NOT REMOVE!
    //<events-bind>
    //</events-bind>
}

//<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

//[UNIT] initialization constructor
