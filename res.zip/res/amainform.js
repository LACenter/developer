////////////////////////////////////////////////////////////////////////////////
// Unit Description  : [UNIT] Description
// Unit Author       : [AUTHOR]
// Date Created      : [DATE]
// -----------------------------------------------------------------------------
//
// History
//
//
////////////////////////////////////////////////////////////////////////////////

//constructor of [UNIT]
function [UNIT]Create(Owner) {
    return TAForm.CreateWithConstructorFromResource(Owner, &[UNIT]_OnCreate, "[UNIT]");
}

//OnCreate Event of [UNIT]
function [UNIT]_OnCreate(Sender) {
    //Form Constructor

    //todo: some additional constructing code

    //note: DESIGNER TAG => DO NOT REMOVE!
    //<events-bind>
    //</events-bind>

    //Set as Application.MainForm
    Sender.setAsMainForm;
}

//<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

//[UNIT] initialization constructor
