'///////////////////////////////////////////////////////////////////////////////
' Unit Description  : [UNIT] Description
' Unit Author       : [AUTHOR]
' Date Created      : [DATE]
' ------------------------------------------------------------------------------
'
' History
'
'
'///////////////////////////////////////////////////////////////////////////////


imports "mainform"

'<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

sub AppException(Sender as TObject, E as Exception)
    'Uncaught Exceptions
    MsgError("Error", E.Message)
end sub

'[UNIT] initialization constructor
Application.Initialize
Application.Icon.LoadFromResource("appicon")
Application.Title = "[UNIT]"
mainformCreate(null)
Application.Run

'Project Resources
'$res:appicon=[project-home]resources/app.ico
'$res:mainform=[project-home]mainform.vb.frm
