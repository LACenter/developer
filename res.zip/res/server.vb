'///////////////////////////////////////////////////////////////////////////////
' Unit Description  : [UNIT] Description
' Unit Author       : [AUTHOR]
' Date Created      : [DATE]
' ------------------------------------------------------------------------------
'
' History
'
'
'///////////////////////////////////////////////////////////////////////////////


'[UNIT] Server OnRequest Event
sub OnRequest()
    ' start coding here
    Response.setContent("Hello World")
end sub

'<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

'[UNIT] initialization constructor
Server.Init
println("Server initialized")
Server.setThreaded(true)
println("Server is Multi-Threaded")
Server.setPort(8181)
println("Server is listening to port 8181")
Server.setQueueSize(100)
println("Server queue size is 100")
println(">> press Ctrl+C to terminate server <<")
Server.Run

