'///////////////////////////////////////////////////////////////////////////////
' Unit Description  : [UNIT] Description
' Unit Author       : [AUTHOR]
' Date Created      : [DATE]
' ------------------------------------------------------------------------------
'
' History
'
'
'///////////////////////////////////////////////////////////////////////////////


'<events-code> - note: DESIGNER TAG => DO NOT REMOVE!

'[UNIT] initialization constructor


